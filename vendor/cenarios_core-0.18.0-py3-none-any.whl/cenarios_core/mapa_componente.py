"""O mapa como componente próprio do Streamlit — para a transição existir.

`st.pydeck_chart` recria o canvas do deck a cada rerun, e por isso a câmera
nunca teve de onde partir (`docs/mapa-clique.md` do tbpe, "Transição"). Este
módulo serve `componente_mapa/`, ao lado dele no pacote, como componente
estático: o iframe fica vivo entre reruns, recebe o mesmo spec JSON que o
pydeck produz e é o JavaScript lá dentro (`mapa.js`) que chama `setProps` na
instância viva — com `FlyToInterpolator` para o enquadramento e
`transitions` para as cores.

O clique volta como ``{"nonce", "properties"}``. O `nonce` muda a cada
clique, inclusive no mesmo polígono — é o que permite o clique repetido
abrir o modo detalhe sem laço de rerun. Quem consome guarda o último nonce
tratado em `st.session_state` e ignora o valor enquanto ele não mudar.

**Envio incremental** (0.8.0). Cor, valor e nome viajavam no mesmo spec que
os polígonos, e a malha inteira voltava pela rede a cada rerun: no tbbrasil,
com os 5.571 municípios, eram 3,9 MB por clique. Simplificar a malha quase
não ajudava (tolerância dobrada: 3,3 MB). Agora a camada GeoJSON grande vai
**em colunas** — uma por chave da feição e por propriedade — cortadas em
pedaços de :data:`PEDACO` linhas, cada pedaço chamado pelo hash do próprio
conteúdo. O navegador guarda os pedaços (`mapa.js`, `guardados`) e o Python
lembra, em `st.session_state`, quais já mandou: do segundo rerun em diante só
vai o conteúdo dos pedaços novos — a cor, o valor, a classe —, e o resto vai
só como hash. A geometria, que não muda, atravessa a rede uma vez por sessão.

Se o iframe recarregar no meio da sessão (o mapa sumiu da tela e voltou), ele
não tem os pedaços que o Python acha que mandou: pede o reenvio pelo valor do
componente (``"falta"``), e o rerun seguinte manda tudo de novo. O pedido
leva o último nonce de clique, para nada navegar à toa.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import streamlit as st
import streamlit.components.v1 as components

DIRETORIO = Path(__file__).resolve().parent / "componente_mapa"

#: Duração do voo entre enquadramentos, em ms. Acima de ~900 parece lentidão;
#: abaixo de ~400 não dá para acompanhar de onde veio.
TRANSICAO_MS = 700

#: Chaves das feições, na ordem de precedência — o padrão serve as camadas
#: municipais do IBGE (tbpe, hansepe, sinan). `cod_mun6` primeiro, porque a
#: feição de município pode carregar a região junto. Outro território passa
#: os seus a `alvo_do_clique`: o RecifeTB, `("bairro_key", "ds")`.
CAMPOS_CLIQUE = ("cod_mun6", "regiao", "uf")

#: Teto da altura do mapa, como múltiplo da largura do iframe (ver `desenhar`).
#: 1,15 é o de Pernambuco, largo; território alto passa ``None``.
PROPORCAO_MAXIMA = 1.15

#: Linhas por pedaço de coluna no envio incremental. Pedaço, e não a coluna
#: inteira, porque quase nada muda inteiro: ao destacar um município a ilha
#: volta ao lugar e só a geometria dela muda — com a coluna como unidade, a
#: malha do Brasil inteira voltava pela rede por causa de Fernando de Noronha.
PEDACO = 512

#: Abaixo disto a camada vai inteira, como antes: o peso é pequeno e o spec
#: fica legível para os testes que o leem do ``json_args`` (RecifeTB, 94
#: bairros; DFTB, 35 RAs). PE, com 185 municípios, já entra no incremental.
MINIMO_FEICOES = 150

#: Marca da camada em colunas dentro do spec. `mapa.js` a reconhece e remonta
#: a ``FeatureCollection`` antes do conversor do deck.gl.
MARCA = "@@cenarios_colunas"

#: Quantos hashes enviados o Python lembra por mapa. Esquecer é seguro —
#: só faz o pedaço ir de novo.
LEMBRADOS = 4096

_componente = components.declare_component("mapa_deck", path=str(DIRETORIO))


def _texto(valor) -> str:
    # `sort_keys`: o hash não pode depender da ordem em que a geometria foi
    # montada — o objeto pydeck e o texto relido a trazem em ordens diferentes.
    return json.dumps(valor, separators=(",", ":"), ensure_ascii=False, allow_nan=False, sort_keys=True)


def _pedaco(valores: list, enviados: dict) -> dict:
    """Um pedaço de coluna: ``{"h"}`` se o navegador já o tem; com ``"v"`` se não.

    Coluna de poucos valores distintos (cor, contorno, classe) vai como
    dicionário — ``{"u": distintos, "i": índices}`` —, que é uma fração do
    tamanho: a cor de 5.571 municípios são sete triplas e 5.571 dígitos.
    """
    # Um `json.dumps` por pedaço, não por valor: por valor eram 240 ms a cada
    # rerun no tbbrasil, mais que o tempo de rede economizado numa conexão
    # boa. Geometria nunca repete, então nem tenta o dicionário.
    distintos: dict = {}
    indices: list[int] | None = []
    for n, v in enumerate(valores, 1):
        k = _chave(v)
        # Coluna que já começa variada (nome, código, valor) não vira
        # dicionário: desiste cedo em vez de chavear 5.571 valores à toa.
        if k is None or (n == 64 and len(distintos) > 32):
            indices = None
            break
        indices.append(distintos.setdefault(k, len(distintos)))
    if indices is not None and len(distintos) <= len(valores) // 2:
        unicos = [None] * len(distintos)
        for v, i in zip(valores, indices):
            unicos[i] = v
        corpo = {"i": indices, "u": unicos}
    else:
        corpo = valores
    texto = _texto(corpo)
    h = hashlib.sha1(texto.encode("utf-8")).hexdigest()[:20]
    if h in enviados:
        enviados[h] = enviados.pop(h)  # o mais recente vai para o fim
        return {"h": h}
    enviados[h] = True
    return {"h": h, "v": corpo, "t": len(texto)}


def _chave(v):
    """Chave de igualdade para o dicionário; ``None`` se o valor é estruturado.

    Leva o tipo junto: ``1``, ``1.0`` e ``True`` são iguais para o Python e
    diferentes no JSON.
    """
    if isinstance(v, list):
        if any(isinstance(x, (list, dict)) for x in v):
            return None
        return tuple((type(x), x) for x in v)
    if isinstance(v, dict):
        return None
    return (type(v), v)


def _em_colunas(colecao, enviados: dict):
    """A ``FeatureCollection`` em colunas de pedaços; ``None`` se não couber.

    Só serve feição uniforme — as mesmas chaves em todas, as mesmas
    propriedades —, que é o que :func:`cenarios_core.mapa.deck` produz. O que
    fugir disso vai inteiro, como antes.
    """
    if not isinstance(colecao, dict) or colecao.get("type") != "FeatureCollection":
        return None
    feicoes = colecao.get("features")
    if not isinstance(feicoes, list) or len(feicoes) < MINIMO_FEICOES:
        return None
    primeira = feicoes[0]
    if not isinstance(primeira, dict) or not isinstance(primeira.get("properties"), dict):
        return None
    chaves = set(primeira) - {"properties"}
    props = set(primeira["properties"])
    for f in feicoes:
        if (not isinstance(f, dict) or not isinstance(f.get("properties"), dict)
                or set(f) - {"properties"} != chaves or set(f["properties"]) != props):
            return None

    def coluna(ler) -> list[dict]:
        return [_pedaco([ler(f) for f in feicoes[i:i + PEDACO]], enviados)
                for i in range(0, len(feicoes), PEDACO)]

    return {
        MARCA: 1,
        "n": len(feicoes),
        "colecao": {k: v for k, v in colecao.items() if k != "features"},
        "feicao": {k: coluna(lambda f, k=k: f[k]) for k in sorted(chaves)},
        "propriedades": {k: coluna(lambda f, k=k: f["properties"][k]) for k in sorted(props)},
    }


def _spec_incremental(texto: str, enviados: dict) -> str:
    spec = json.loads(texto)
    mudou = False
    for camada in spec.get("layers") or []:
        if isinstance(camada, dict) and camada.get("@@type") == "GeoJsonLayer":
            colunas = _em_colunas(camada.get("data"), enviados)
            if colunas is not None:
                camada["data"] = colunas
                mudou = True
    return _texto(spec) if mudou else texto


def _spec_incremental_deck(mapa_deck, enviados: dict) -> str | None:
    """O mesmo que :func:`_spec_incremental`, direto do objeto pydeck.

    Poupa o ``json.loads`` do spec que `mapa.deck` já serializou — 60 ms a
    cada rerun no tbbrasil. A camada troca de dados só durante o
    ``json.dumps`` e volta ao que era. ``None`` quando não há o que trocar
    ou a API interna do pydeck mudou; aí vale o caminho pelo texto.
    """
    try:
        from pydeck.bindings.json_tools import default_serialize

        camadas = list(mapa_deck.layers)
    except (ImportError, AttributeError, TypeError):
        return None
    trocas = []
    for camada in camadas:
        if getattr(camada, "type", None) != "GeoJsonLayer" or not hasattr(camada, "_data"):
            continue
        colunas = _em_colunas(camada._data, enviados)
        if colunas is not None:
            trocas.append((camada, camada._data))
            camada._data = colunas
    if not trocas:
        return None
    # O `to_json` que `mapa._compactar` pendura na instância seria
    # serializado junto, como `"toJson": {}`; sai durante o dump.
    proprio = vars(mapa_deck).pop("to_json", None)
    try:
        return json.dumps(mapa_deck, sort_keys=True, default=default_serialize,
                          separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    finally:
        for camada, dados in trocas:
            camada._data = dados
        if proprio is not None:
            mapa_deck.to_json = proprio


def expandir(spec: dict, guardados: dict | None = None) -> dict:
    """O spec como o navegador o vê: as camadas em colunas de volta a GeoJSON.

    Para teste e inspeção — é o que `mapa.js` faz antes do conversor.
    ``guardados`` acumula ``hash → valores`` entre chamadas, como o
    navegador; sem ele, só se expande o spec que traz todos os pedaços (o da
    primeira carga). Pedaço ausente levanta ``KeyError``.
    """
    guardados = {} if guardados is None else guardados

    def ler(pedacos: list[dict]) -> list:
        saida: list = []
        for p in pedacos:
            saida += guardados[p["h"]]
        return saida

    spec = json.loads(json.dumps(spec))
    camadas = [c.get("data") for c in spec.get("layers") or [] if isinstance(c, dict)]
    camadas = [d for d in camadas if isinstance(d, dict) and MARCA in d]
    # Guarda tudo antes de ler: pedaço repetido no mesmo spec (`rotulo` igual
    # a `nome_mun`) só traz o conteúdo na primeira vez.
    for dados in camadas:
        for col in [*dados["feicao"].values(), *dados["propriedades"].values()]:
            for p in col:
                if "v" in p:
                    v = p["v"]
                    guardados[p["h"]] = [v["u"][i] for i in v["i"]] if isinstance(v, dict) else v
    for camada in spec.get("layers") or []:
        dados = camada.get("data") if isinstance(camada, dict) else None
        if not (isinstance(dados, dict) and MARCA in dados):
            continue
        feicao = {k: ler(v) for k, v in dados["feicao"].items()}
        props = {k: ler(v) for k, v in dados["propriedades"].items()}
        camada["data"] = dict(dados["colecao"], features=[
            dict({k: col[i] for k, col in feicao.items()},
                 properties={k: col[i] for k, col in props.items()})
            for i in range(dados["n"])
        ])
    return spec


def desenhar(
    mapa_deck,
    *,
    altura: int,
    key: str = "mapa",
    transicao: int = TRANSICAO_MS,
    titulo: str | None = None,
    proporcao_maxima: float | None = PROPORCAO_MAXIMA,
    incremental: bool = True,
):
    """Renderiza o `pydeck.Deck` no componente e devolve o último clique.

    A ``key`` é **estável de propósito**: é ela que mantém o iframe — e a
    instância do deck — vivos entre reruns. Não inclua o recorte nela.

    ``titulo`` é o nome do quadro para leitor de tela — "Mapa de Pernambuco:
    Incidência", "Mapa do Recife". Sem ele o quadro se chama só "Mapa", que
    ainda é melhor que o nome interno que o Streamlit dá.

    A ``altura`` é a de tela de trabalho. Em tela estreita o próprio iframe a
    limita a 1,15 vez a largura (`mapa.js`, `alturaUtil`): Pernambuco é largo,
    e num aparelho de 375px a caixa de 640 de altura deixava ~500px de vazio.
    ``proporcao_maxima`` é esse teto — o padrão serve a território largo; o
    RecifeTB, alto, passa ``None`` e a altura pedida vale sempre.

    ``incremental`` liga o envio só do que mudou (ver o topo do módulo);
    ``False`` manda o spec inteiro a cada rerun, como até o 0.7.0.
    """
    texto = None
    if incremental:
        memoria = f"_cenarios_mapa_enviados::{key}"
        enviados = st.session_state.get(memoria)
        if not isinstance(enviados, dict):
            enviados = {}
        # O iframe recarregou e não tem o que o Python acha que mandou: o
        # pedido é atendido uma vez (o valor do componente persiste entre
        # reruns, e sem a memória do pedido tudo iria em todo rerun).
        anterior = st.session_state.get(key)
        pedido = anterior.get("falta") if isinstance(anterior, dict) else None
        if pedido and pedido != st.session_state.get(memoria + "::pedido"):
            st.session_state[memoria + "::pedido"] = pedido
            enviados = {}
        direto = _spec_incremental_deck(mapa_deck, enviados)
        texto = direto if direto is not None else _spec_incremental(mapa_deck.to_json(), enviados)
        while len(enviados) > LEMBRADOS:
            enviados.pop(next(iter(enviados)))
        st.session_state[memoria] = enviados

    valor = _componente(
        spec=texto if texto is not None else mapa_deck.to_json(),
        tooltip=getattr(mapa_deck, "_tooltip", None),
        altura=int(altura),
        transicao=int(transicao),
        titulo=titulo,
        proporcao_maxima=proporcao_maxima,
        key=key,
        default=None,
    )
    # O pedido de reenvio não é clique: quem chama recebe só o clique.
    if isinstance(valor, dict) and "falta" in valor:
        valor = {k: v for k, v in valor.items() if k != "falta"} if valor.get("nonce") else None
    return valor


def alvo_do_clique(
    evento, nonce_visto: str | None, campos: tuple[str, ...] = CAMPOS_CLIQUE
) -> tuple[str | None, str | None]:
    """``(chave clicada, nonce)`` se o evento é novo; ``(None, None)`` se não.

    ``campos`` são as chaves das feições na ordem de precedência — a primeira
    que existir ganha. É o único ponto do componente que sabe de território:
    o RecifeTB passa ``("bairro_key", "ds")``, o DFTB a chave da RA.
    """
    if not isinstance(evento, dict):
        return None, None
    nonce = evento.get("nonce")
    if not nonce or nonce == nonce_visto:
        return None, None
    props = evento.get("properties")
    if not isinstance(props, dict):
        return None, nonce
    for campo in campos:
        if props.get(campo):
            return str(props[campo]), nonce
    return None, nonce
