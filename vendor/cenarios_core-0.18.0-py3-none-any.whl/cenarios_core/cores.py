"""Matemática de cor que os gráficos usam: rampa, contraste e luminosidade.

Veio do tema do hansepe (`theme/cores.py` e `theme/visao.py`), que os outros
painéis copiaram igual. Não tem cor de painel nenhum — só as contas. A
**paleta** de cada painel continua no painel.
"""

from __future__ import annotations

Rgb = tuple[float, float, float]

#: Proporções de mistura da rampa: três tons mais claros que a base e três
#: mais escuros. Os valores são os do dashboard em R; no lado escuro, ``t`` é
#: o peso do preto (no R era o da base, e a rampa saía não monotônica).
_CLAROS = (0.35, 0.55, 0.72)
_ESCUROS = (0.18, 0.34, 0.52)

BRANCO = "#FFFFFF"
PRETO = "#000000"


def hex_para_rgb(cor: str) -> Rgb:
    """``#RRGGBB`` (ou ``#RGB``) para três canais de 0 a 1."""
    texto = str(cor or "").strip().lstrip("#")
    if len(texto) == 3:
        texto = "".join(c * 2 for c in texto)
    if len(texto) != 6:
        raise ValueError(f"Cor hexadecimal inválida: {cor!r}")
    return tuple(int(texto[i : i + 2], 16) / 255 for i in (0, 2, 4))  # type: ignore[return-value]


def rgb_para_hex(rgb: Rgb) -> str:
    return "#" + "".join(f"{round(max(0.0, min(1.0, c)) * 255):02X}" for c in rgb)


def misturar(a: str, b: str, t: float) -> str:
    """Interpola linearmente entre duas cores. ``t=0`` devolve ``a``, ``t=1`` devolve ``b``."""
    ra, rb = hex_para_rgb(a), hex_para_rgb(b)
    return rgb_para_hex(  # type: ignore[arg-type]
        tuple(x + (y - x) * t for x, y in zip(ra, rb, strict=True))
    )


def rampa(base: str) -> list[str]:
    """Rampa sequencial de 7 tons: três mais claros, a base no meio, três mais escuros."""
    claros = [misturar(BRANCO, base, t) for t in _CLAROS]
    escuros = [misturar(base, PRETO, t) for t in _ESCUROS]
    return [*claros, base.upper(), *escuros]


def _luminancia(cor: str) -> float:
    canais = []
    for x in hex_para_rgb(cor):
        canais.append(x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4)
    r, g, b = canais
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contraste(a: str, b: str) -> float:
    """Razão de contraste entre duas cores, de 1 a 21 (WCAG 2.1)."""
    la, lb = _luminancia(a), _luminancia(b)
    claro, escuro = max(la, lb), min(la, lb)
    return (claro + 0.05) / (escuro + 0.05)


def _srgb_para_linear(c: float) -> float:
    c = c / 255
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _para_lab(hexa: str) -> tuple[float, float, float]:
    texto = hexa.lstrip("#")
    r, g, b = (_srgb_para_linear(int(texto[i:i + 2], 16)) for i in (0, 2, 4))
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 1.0
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883

    def f(t: float) -> float:
        return t ** (1 / 3) if t > 0.008856 else (7.787 * t + 16 / 116)

    fx, fy, fz = f(x), f(y), f(z)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


def luminosidade(hexa: str) -> float:
    """L* da cor, de 0 (preto) a 100 (branco).

    É o canal que sobrevive a qualquer daltonismo: separar duas coisas por
    luminosidade funciona para todo mundo, separar por matiz não.
    """
    return _para_lab(hexa)[0]
